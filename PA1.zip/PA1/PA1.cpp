
#include "PA1.h"

node::node() {
	this->data = -1;
	this->pNext = nullptr;
}
node::~node() {
	delete(pNext);
}

node::node(node* copy) {
	this->data = copy->data;
	this->pNext = copy->pNext;
}

int node::getData() {
	return data;
}
node* node::getPNext() {
	return pNext;
}

void node::setData(int a) {
	this->data = a;
}
void node::setPNext(node *n) {
	this->pNext = n;
}

linkedList::linkedList() {
	amt = 0;
	max = 0;// only works if there is at least 1 number > 0
	pTop = nullptr;
}
linkedList::~linkedList(){}

void linkedList::setPtop(node* t) {
	pTop = t;
}
void linkedList::setAmt(int a) {
	amt = a;
}
void linkedList::incriment() {
	amt++;
}
node* linkedList::getPtop() {
	return pTop;
}
int linkedList::getAmt() {
	return amt;
}

node* linkedList::makeNode(int d) {
	node* pNew = nullptr;
	pNew = new node;

	pNew->setData(d);

	return pNew;

}

void linkedList::insertInorder(node* n) {

	if (n != nullptr) {

		node* pCur = nullptr;
		node* pPre = nullptr;

		if (pTop == nullptr) {
			pTop = n;
		}

		else {
			pCur = pTop;
			//cout << pCur->getData() << " >" << n->getData();
			while (pCur != nullptr&& pCur->getData() < n->getData()  ) {
				pPre = pCur;
				pCur = pCur->getPNext();


			}
			if (pPre == nullptr) {
				if (pCur->getData() > n->getData()) {
					n->setPNext(pCur);
					pTop = n;
				}
				else {
					pCur->setPNext(n);
				}
			}
			else {
				pPre->setPNext(n);
				n->setPNext(pCur);

			}
		//	
			

		}

		if (n->getData() > max) {
			max = n->getData();
		}

	}
}
int linkedList::getMax() {

	return max;
}

int linkedList::getMin() {
	return pTop->getData();

}

int linkedList:: getMid() {
	node* pCur = nullptr;

	if (pTop != nullptr) {
		pCur = pTop;

		for (int i = 0; i < amt / 2; i++) {
			pCur = pCur->getPNext();
		}

		return pCur->getData();
	}
	return -1;

}

void linkedList:: displayAll() {

	node* pCur=nullptr;

	pCur = pTop;

	while (pCur != nullptr) {
		cout << pCur->getData() << endl;
		pCur = pCur->getPNext();

	}
}

