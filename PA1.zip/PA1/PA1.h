//PA1.h
#include <iostream>
#include <fstream>
#include <string>
#include <cstdlib>
#include <chrono>

using namespace::std;

class node {

public:
	node();
	~node();

	node(node* copy);

	int getData();
	node* getPNext();

	void setData(int a);
	void setPNext(node *n);



private:
	int data;
	node *pNext;

};


class linkedList {
public:
	linkedList();
	~linkedList();
	
	void setPtop(node* t);
	void setAmt(int a);
	void incriment();
	node* getPtop();
	int getAmt();

	int getMin();
	int getMax();
	int getMid();

	node* makeNode(int d);
	void insertInorder(node* n);

	void displayAll();

private:
	node *pTop;
	int amt;
	int max;

};

int stringToInt(string s);

