	
#include "PA1.h"

//specified what all these functions are in PA1.h

int stringToInt(string s) {
	
	
		int ret = 0;
		for (int i = 0; i < s.length()-1; i++) {
			ret = ret + (s[i]-48);
			ret=ret * 10;
}
		ret = ret + (s[s.length() - 1] - 48);
		return ret;
}


node::node() {
	this->data = -1;
	this->pNext = nullptr;
}
node::~node() {
	delete(pNext);
}

node::node(node* copy) {
	this->data = copy->data;
	this->pNext = copy->pNext;
}

int node::getData() {
	return data;
}
node* node::getPNext() {
	return pNext;
}

void node::setData(int a) {
	this->data = a;
}
void node::setPNext(node *n) {
	this->pNext = n;
}

linkedList::linkedList() {
	amt = 0;
	max = 0;// only works if there is at least 1 number > 0
	pTop = nullptr;
}
linkedList::~linkedList(){}

void linkedList::setPtop(node* t) {
	pTop = t;
}
void linkedList::setAmt(int a) {
	amt = a;
}
void linkedList::incriment() {
	amt++;
}
node* linkedList::getPtop() {
	return pTop;
}
int linkedList::getAmt() {
	return amt;
}

node* linkedList::makeNode(int d) {
	node* pNew = nullptr;
	pNew = new node;

	pNew->setData(d);

	return pNew;

}

void linkedList::insertInorder(node* n) {

	//checks to make sure n is not a null ptr
	if (n != nullptr) {

		node* pCur = nullptr;
		node* pPre = nullptr;


		//if linked list is impty
		if (pTop == nullptr) {
			pTop = n;
		}

		else {
			pCur = pTop;
			
		//traverses list until iether it finds its spot or reaches the end of the list
		while (pCur != nullptr&& pCur->getData() < n->getData()  ) {
				pPre = pCur;
				pCur = pCur->getPNext();


			}
			//if second first or second item
			if (pPre == nullptr) {
				//if n is less then the first item in the list
				if (pCur->getData() > n->getData()) {
					n->setPNext(pCur);
					pTop = n;
				}
				//if pPre = null and n>first item
				else {
					pCur->setPNext(n);
				}
			}

			else {
				pPre->setPNext(n);
				n->setPNext(pCur);

			}
		//	
			

		}
		// finds max value in list
		if (n->getData() > max) {
			max = n->getData();
		}

	}
}
int linkedList::getMax() {

	return max;
}

int linkedList::getMin() {
	return pTop->getData();

}

int linkedList:: getMid() {
	node* pCur = nullptr;

	if (pTop != nullptr) {
		pCur = pTop;

		for (int i = 0; i < amt / 2; i++) {
			pCur = pCur->getPNext();
		}

		return pCur->getData();
	}
	return -1;

}

void linkedList:: displayAll() {

	node* pCur=nullptr;

	pCur = pTop;

	while (pCur != nullptr) {
		cout << pCur->getData() << endl;
		pCur = pCur->getPNext();

	}
}



int main (){
	linkedList a;
	fstream input;
	string s;
	string file;
	int k=0,i=0;
	

	cout << "pick a file name: "<<endl;
		
	cin >> file;

	file = file + ".txt";

//	file = "Input2.txt";

	input.open(file);

	//startsclock //aquired line from cplusplus.com 
	auto start = std::chrono::steady_clock::now();
int x;

	while (input >> x) {
		

		a.insertInorder(a.makeNode(x));
		a.incriment();

	}


	auto elapsed = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::steady_clock::now() - start);



	cout << "_________" << endl << "amt:" << a.getAmt() << endl << "min:" << a.getPtop()->getData() << endl << "max:" << a.getMax() << endl<<"med:"<<a.getMid()<<endl;

	std::cout << "milliseconds since start: " << elapsed.count() << '\n';
}



